/*otavio_augusto
tamoni_monise*/

#include <stdio.h>
#include <stdlib.h>
#include "../include/hotelarpj.h"
#include "../lib/hotelar_funcoes.c"

int main() {
    menuPrincipal();
    return 0;
}