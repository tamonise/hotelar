/*OTAVIO_AUGUSTO
TAMONI_MONISE*/

#include <stdio.h>
#include <stdlib.h>
#include <strings.h>
#ifndef HOTELARPJ_OPERATIONS_H
#define HOTELARPJ_OPERATIONS_H



//CRIANDO AS ESTRUTURAS QUE UTILIZAREMOS PARA REGISTRAR O QUERIDO HOSPEDE NO HOTEL.
// criando estrutura de dados para registro de quarto, quantidade de camas e quanto seria o valor de sua diaria
typedef struct {
    int numeroDoQuarto;
    int quantidadeDeCamas;
    float precoDiaria;
} Quarto;
/* criando estrutura de dados para registrar o veículo do hospede no estacionamento,
adicionando a placa, o numero da vaga, o modelo e a cor do carro.*/
typedef struct {
    int numeroDaVaga;
    char placaDoCarro[7];
    char modeloDoCarro[20];
    char corDoCarro[20];
} Estacionamento;
/*cria uma estrutura show de bola de dados
 que registra o hospede com todas suas informações pessoais,
 se possui um carro para o nosso chique estacionamento e a forma de pagamento*/
typedef struct {
    int id;
    char nome[50];
    int telefone;
    int cpf;
    int cep;
    char endereco[70];
    char acompanhante[50];
    int numeroDoCartao;
    int cvv;
    Quarto quarto;
    int possuiCarro;
    Estacionamento estacionamento;
} Hospede;

/*cria uma estrutura de dados contendo os dados do hospede, implementada por meio de nós encadeados,
no caso, *prox é um ponteiro para o próximo no da fila*/


typedef struct no {
    Hospede dado;
    struct no *prox;
} No;
/*cria uma estrutura de dados contendo um ponteiro
um para o inicio e um para o fim, acrescentando uma variavel inteira que armazenará o tamanho para a Fila*/
typedef struct {
    No *inicio;
    No *fim;
    int tamFila;
} Fila;
// cria uma variavel para o ultimo id
int ultimoId = 0;

void menuPrincipal();

Hospede checkInNovoCliente();

void cria(Fila *fila);

int estaVazia(Fila fila);

int insere(Fila *fila, Hospede dado);

int procurarRemoverHospede(Fila *fila, int id);
//Função responsavel por remover os dados do hospede da fila.

void mostrarClientesEstacionamento(Fila fila);

void QuartosOcupados(int quantidade, Fila *fila);
